import { LightningElement, api } from 'lwc';

const DEFAULT_SCROLL_INTERVAL = 5000;
const ALIGNMENTS = new Set(['left', 'center', 'right']);
const FONT_FAMILIES = new Set(['salesforceSans', 'serif', 'monospace', 'cursive']);
const FONT_STYLES = new Set(['normal', 'bold', 'italic', 'boldItalic']);
const DEFAULT_BUTTON_BACKGROUND_RGB = '161, 32, 58';
const DEFAULT_BUTTON_TEXT_RGB = '255, 255, 255';

export default class DynamicHeroBanner extends LightningElement {
  @api imageOneUrl;
  @api imageTwoUrl;
  @api imageThreeUrl;
  @api slideOneHeading;
  @api slideOneSubText;
  @api slideOneButtonOneLabel;
  @api slideOneButtonOneUrl;
  @api slideOneButtonTwoLabel;
  @api slideOneButtonTwoUrl;
  @api slideTwoHeading;
  @api slideTwoSubText;
  @api slideTwoButtonOneLabel;
  @api slideTwoButtonOneUrl;
  @api slideTwoButtonTwoLabel;
  @api slideTwoButtonTwoUrl;
  @api slideThreeHeading;
  @api slideThreeSubText;
  @api slideThreeButtonOneLabel;
  @api slideThreeButtonOneUrl;
  @api slideThreeButtonTwoLabel;
  @api slideThreeButtonTwoUrl;
  @api buttonBackgroundRgb = DEFAULT_BUTTON_BACKGROUND_RGB;
  @api buttonTextRgb = DEFAULT_BUTTON_TEXT_RGB;
  @api pauseOnHover = false;

  _autoScrollInterval = DEFAULT_SCROLL_INTERVAL;
  _overlayAlignment = 'left';
  _fontFamily = 'salesforceSans';
  _fontStyle = 'normal';
  currentSlideIndex = 0;
  intervalId;

  @api
  get autoScrollInterval() {
    return this._autoScrollInterval;
  }

  set autoScrollInterval(value) {
    const interval = Number(value);
    this._autoScrollInterval = interval > 0 ? interval : DEFAULT_SCROLL_INTERVAL;
    if (this.isConnected) {
      this.restartAutoScroll();
    }
  }

  @api
  get overlayAlignment() {
    return this._overlayAlignment;
  }

  set overlayAlignment(value) {
    this._overlayAlignment = ALIGNMENTS.has(value) ? value : 'left';
  }

  @api
  get fontFamily() {
    return this._fontFamily;
  }

  set fontFamily(value) {
    this._fontFamily = FONT_FAMILIES.has(value) ? value : 'salesforceSans';
  }

  @api
  get fontStyle() {
    return this._fontStyle;
  }

  set fontStyle(value) {
    this._fontStyle = FONT_STYLES.has(value) ? value : 'normal';
  }

  connectedCallback() {
    this.startAutoScroll();
  }

  renderedCallback() {
    this.startAutoScroll();
  }

  disconnectedCallback() {
    this.stopAutoScroll();
  }

  get configuredSlides() {
    return [
      {
        imageUrl: this.imageOneUrl,
        heading: this.slideOneHeading,
        subText: this.slideOneSubText,
        buttonOneLabel: this.slideOneButtonOneLabel,
        buttonOneUrl: this.slideOneButtonOneUrl,
        buttonTwoLabel: this.slideOneButtonTwoLabel,
        buttonTwoUrl: this.slideOneButtonTwoUrl
      },
      {
        imageUrl: this.imageTwoUrl,
        heading: this.slideTwoHeading,
        subText: this.slideTwoSubText,
        buttonOneLabel: this.slideTwoButtonOneLabel,
        buttonOneUrl: this.slideTwoButtonOneUrl,
        buttonTwoLabel: this.slideTwoButtonTwoLabel,
        buttonTwoUrl: this.slideTwoButtonTwoUrl
      },
      {
        imageUrl: this.imageThreeUrl,
        heading: this.slideThreeHeading,
        subText: this.slideThreeSubText,
        buttonOneLabel: this.slideThreeButtonOneLabel,
        buttonOneUrl: this.slideThreeButtonOneUrl,
        buttonTwoLabel: this.slideThreeButtonTwoLabel,
        buttonTwoUrl: this.slideThreeButtonTwoUrl
      }
    ]
      .map((slide) => ({
        ...slide,
        imageUrl: this.trimValue(slide.imageUrl),
        heading: this.trimValue(slide.heading),
        subText: this.trimValue(slide.subText),
        buttonOneLabel: this.trimValue(slide.buttonOneLabel),
        buttonOneUrl: this.trimValue(slide.buttonOneUrl),
        buttonTwoLabel: this.trimValue(slide.buttonTwoLabel),
        buttonTwoUrl: this.trimValue(slide.buttonTwoUrl)
      }))
      .filter((slide) => Boolean(slide.imageUrl));
  }

  get slides() {
    const activeIndex = this.normalizedSlideIndex;
    return this.configuredSlides.map((slide, index) => ({
      id: `${index}-${slide.imageUrl}`,
      url: slide.imageUrl,
      heading: slide.heading,
      subText: slide.subText,
      buttonOneLabel: slide.buttonOneLabel,
      buttonOneUrl: slide.buttonOneUrl,
      buttonTwoLabel: slide.buttonTwoLabel,
      buttonTwoUrl: slide.buttonTwoUrl,
      altText: slide.heading || 'Hero banner image',
      className: index === activeIndex ? 'indicator active' : 'indicator'
    }));
  }

  get normalizedSlideIndex() {
    const slideCount = this.configuredSlides.length;
    return slideCount ? this.currentSlideIndex % slideCount : 0;
  }

  get currentSlide() {
    return this.slides[this.normalizedSlideIndex] || {};
  }

  get currentImageUrl() {
    return this.currentSlide.url;
  }

  get currentImageAltText() {
    return this.currentSlide.altText;
  }

  get overlayClass() {
    return `overlay overlay-${this.overlayAlignment} font-family-${this.fontFamily} font-style-${this.fontStyle}`;
  }

  get validButtonBackgroundRgb() {
    return this.getValidRgb(this.buttonBackgroundRgb, DEFAULT_BUTTON_BACKGROUND_RGB);
  }

  get validButtonTextRgb() {
    return this.getValidRgb(this.buttonTextRgb, DEFAULT_BUTTON_TEXT_RGB);
  }

  get buttonStyle() {
    return `--hero-button-background: rgb(${this.validButtonBackgroundRgb}); --hero-button-text: rgb(${this.validButtonTextRgb});`;
  }

  get hasHeading() {
    return Boolean(this.currentSlide.heading);
  }

  get hasSubText() {
    return Boolean(this.currentSlide.subText);
  }

  get hasButtonOne() {
    return Boolean(this.currentSlide.buttonOneLabel && this.currentSlide.buttonOneUrl);
  }

  get hasButtonTwo() {
    return Boolean(this.currentSlide.buttonTwoLabel && this.currentSlide.buttonTwoUrl);
  }

  get hasButtons() {
    return this.hasButtonOne || this.hasButtonTwo;
  }

  get hasOverlayContent() {
    return this.hasHeading || this.hasSubText || this.hasButtons;
  }

  get hasIndicators() {
    return this.slides.length > 1;
  }

  get hasImage() {
    return Boolean(this.currentImageUrl);
  }

  handleMouseEnter() {
    if (this.pauseOnHover) {
      this.stopAutoScroll();
    }
  }

  handleMouseLeave() {
    if (this.pauseOnHover) {
      this.startAutoScroll();
    }
  }

  startAutoScroll() {
    if (this.intervalId || this.slides.length <= 1) {
      return;
    }

    this.intervalId = window.setInterval(() => {
      this.currentSlideIndex = this.normalizedSlideIndex + 1;
    }, this.autoScrollInterval);
  }

  stopAutoScroll() {
    if (!this.intervalId) {
      return;
    }

    window.clearInterval(this.intervalId);
    this.intervalId = undefined;
  }

  restartAutoScroll() {
    this.stopAutoScroll();
    this.startAutoScroll();
  }

  trimValue(value) {
    return (value || '').trim();
  }

  getValidRgb(value, fallback) {
    const rgbParts = this.trimValue(value)
      .split(',')
      .map((part) => Number(part.trim()));

    const isValidRgb =
      rgbParts.length === 3 &&
      rgbParts.every((part) => Number.isInteger(part) && part >= 0 && part <= 255);

    return isValidRgb ? rgbParts.join(', ') : fallback;
  }
}
